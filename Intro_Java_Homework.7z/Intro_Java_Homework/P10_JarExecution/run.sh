#!/bin/bash
java -jar /home/asen/workspace/Intro_Java_Homework/P10_JarExecution/CardsPdf.jar
