
public class P3_PrintYourHometown {
	public static void main (String[] args) {
		System.out.println("Sofia");
	}

}
